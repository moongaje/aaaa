# !/bin/bash

read -p "[?] Input list number with country code : " ask_lst
read -p "[?] Input from number with country code : " ask_fn
read -p "[?] Input letter ( single letter ) : " ask_msg

for lst_num in $(cat $ask_lst); do
	az communication sms send \
		--sender "${ask_fn}" \
		--recipient "${lst_num}" \
		--message "$(cat $ask_msg)" \
		--connection-string "endpoint=https://baruasu.communication.azure.com/;accesskey=pfHAp4iNjz3CczZUjTiErxXGzvFIiHbQID6BK4rS6GcDtPs2hypRVj/THxcjGFu6DBNT/KygMwSEX1XkveXsvQ=="
		sleep 3
done